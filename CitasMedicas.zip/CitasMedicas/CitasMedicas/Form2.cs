﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CitasMedicas
{
    public partial class MenuPrin : Form
    {
        public MenuPrin()
        {
            InitializeComponent();
            // Asigna eventos de click y color a cada panel
            btnRegistrar.Click += PanelRegistrarPacientes_Click;
            btnRegistrar.MouseEnter += Panel_MouseEnter;
            btnRegistrar.MouseLeave += Panel_MouseLeave;
            btnRegistrar.MouseDown += Panel_MouseDown;
            btnRegistrar.MouseUp += Panel_MouseUp;

            btnAgregar.Click += PanelAgregarCitas_Click;
            btnAgregar.MouseEnter += Panel_MouseEnter;
            btnAgregar.MouseLeave += Panel_MouseLeave;
            btnAgregar.MouseDown += Panel_MouseDown;
            btnAgregar.MouseUp += Panel_MouseUp;

            btnAgenda.Click += PanelCitasAgendadas_Click;
            btnAgenda.MouseEnter += Panel_MouseEnter;
            btnAgenda.MouseLeave += Panel_MouseLeave;
            btnAgenda.MouseDown += Panel_MouseDown;
            btnAgenda.MouseUp += Panel_MouseUp;

            btnPacientes.Click += PanelPacientes_Click;
            btnPacientes.MouseEnter += Panel_MouseEnter;
            btnPacientes.MouseLeave += Panel_MouseLeave;
            btnPacientes.MouseDown += Panel_MouseDown;
            btnPacientes.MouseUp += Panel_MouseUp;

            btnMedicos.Click += PanelMedicos_Click;
            btnMedicos.MouseEnter += Panel_MouseEnter;
            btnMedicos.MouseLeave += Panel_MouseLeave;
            btnMedicos.MouseDown += Panel_MouseDown;
            btnMedicos.MouseUp += Panel_MouseUp;

            btnSalir.Click += PanelSalir_Click;
            btnSalir.MouseEnter += Panel_MouseEnter;
            btnSalir.MouseLeave += Panel_MouseLeave;
            btnSalir.MouseDown += Panel_MouseDown;
            btnSalir.MouseUp += Panel_MouseUp;
        }

        private void PanelSalir_Click(object sender, EventArgs e)
        {
            Inicio formularioIni = new Inicio();
            formularioIni.Show();
            this.Hide();
        }

        // Métodos para cambiar el color al pasar el cursor sobre el panel
        private void Panel_MouseEnter(object sender, EventArgs e)
        {
            ((Panel)sender).BackColor = Color.LightGray;
        }

        private void Panel_MouseLeave(object sender, EventArgs e)
        {
            ((Panel)sender).BackColor = Color.SteelBlue;
        }

        private void Panel_MouseDown(object sender, MouseEventArgs e)
        {
            ((Panel)sender).BackColor = Color.DarkGray;
        }

        private void Panel_MouseUp(object sender, MouseEventArgs e)
        {
            ((Panel)sender).BackColor = Color.LightGray;
        }

        private void PanelRegistrarPacientes_Click(object sender, EventArgs e)
        {
            Registro formularioRegistro = new Registro();
            formularioRegistro.Show();
            this.Hide();
        }

        private void PanelAgregarCitas_Click(object sender, EventArgs e)
        {
            AgregarCita formularioCitas = new AgregarCita();
            formularioCitas.Show();
            this.Hide();
        }

        private void PanelCitasAgendadas_Click(object sender, EventArgs e)
        {
            Agenda formularioAgregarCitas = new Agenda();
            formularioAgregarCitas.Show();
            this.Hide();
        }

        private void PanelPacientes_Click(object sender, EventArgs e)
        {
            Pacientes formularioPacientes = new Pacientes();
            formularioPacientes.Show();
            this.Hide();
        }

        private void PanelMedicos_Click(object sender, EventArgs e)
        {
            Medicos formularioMedicos = new Medicos();
            formularioMedicos.Show();
            this.Hide();
        }
    }
}