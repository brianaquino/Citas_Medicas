﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace CitasMedicas
{
    public partial class AgregarCita : Form
    {
        //Datos de conexion a MySQL
        string conexionSQL = "Server=localhost;Port=3306;Database=sisterma_citas;Uid=root;Pwd=Sayuris71700305;";

        // Diccionario que asocia médicos con consultorios
        private Dictionary<string, string> medicoConsultorioMap = new Dictionary<string, string>
        {
            { "LM-4820193", "1" },
            { "LM-7610548", "2" },
            { "LM-2396745", "3" },
            { "LM-5842179", "4" },
            { "LM-9023516", "5" }
        };

        public AgregarCita()
        {
            InitializeComponent();

            tbNoCita.TextChanged += ValidarNoCita;
            tbNSS.Leave += ValidarNSS;
            cbMedico.SelectedIndexChanged += MedicoSeleccionado;
            cbConsultorio.SelectedIndexChanged += ValidarConsultorio;
            dtpCita.MaxDate = DateTime.Today;
            cbHora.SelectedIndexChanged += ValidarHora;
            tbMotivo.TextChanged += ValidarMotivo;
            // Configurar evento de CheckBox para asegurarse de que solo uno esté seleccionado
            chbPendiente.CheckedChanged += ValidarEstado;
            chbConfirmada.CheckedChanged += ValidarEstado;
            chbCancelada.CheckedChanged += ValidarEstado;
        }

        private void MedicoSeleccionado(object sender, EventArgs e)
        {
            // Obtener el nombre del médico seleccionado en cbMedico
            string medicoSeleccionado = cbMedico.SelectedItem?.ToString();

            if (medicoSeleccionado != null && medicoConsultorioMap.ContainsKey(medicoSeleccionado))
            {
                // Consultar el número de consultorio en el diccionario y asignarlo en cbConsultorio
                string consultorio = medicoConsultorioMap[medicoSeleccionado];
                cbConsultorio.SelectedItem = consultorio;

                // Si el consultorio no existe en el ComboBox, lo agrega
                if (!cbConsultorio.Items.Contains(consultorio))
                {
                    cbConsultorio.Items.Add(consultorio);
                }

                cbConsultorio.SelectedItem = consultorio; // Selecciona el consultorio
            }
            else
            {
                // Si no se encuentra el médico, reiniciar la selección del consultorio
                cbConsultorio.SelectedIndex = -1;
            }
        }


        private void InsertarRegistro(string noCita, string nss, string medico, string consultorio, string fechaCita, string hora, string motivo,string estado)
        {
            using (MySqlConnection connection = new MySqlConnection(conexionSQL))
            {
                connection.Open();

                string insertQuery = "INSERT INTO citasagendadas (Id_Cita, Id_Paciente, Id_Medico, Id_Consultorio, Fecha_Cita, Hora, Motivo, Estado) " +
                                         "VALUES (@Id_Cita, @Id_Paciente, @Id_Medico, @Id_Consultorio, @Fecha_Cita, @Hora, @Motivo, @Estado)";


                using (MySqlCommand command = new MySqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@Id_Cita", noCita);
                    command.Parameters.AddWithValue("@Id_Paciente", nss);
                    command.Parameters.AddWithValue("@Id_Medico", medico);
                    command.Parameters.AddWithValue("@Id_Consultorio", consultorio);
                    command.Parameters.AddWithValue("@Fecha_Cita", fechaCita);
                    command.Parameters.AddWithValue("@Hora", hora);
                    command.Parameters.AddWithValue("@Motivo", motivo);
                    command.Parameters.AddWithValue("@Estado", estado);


                    command.ExecuteNonQuery();
                }
                connection.Close();
            }
        }

        private void Agendar_Click(object sender, EventArgs e)
        {
            string noCita = tbNoCita.Text;
            string nss = tbNSS.Text;
            string medico = cbMedico.SelectedItem?.ToString();
            string consultorio = cbConsultorio.SelectedItem?.ToString();
            string fechaCita = dtpCita.Value.ToString("yyyy/MM/dd");
            string hora = cbHora.SelectedItem?.ToString();
            string motivo = tbMotivo.Text;
            string estado = ObtenerEstadoCita();

            if (EsEnteroValido(noCita) && EsEnteroValidoDe9Digitos(nss) && EsTextoValido(motivo) && !string.IsNullOrEmpty(medico) && !string.IsNullOrEmpty(consultorio) && !string.IsNullOrEmpty(hora) && !string.IsNullOrEmpty(estado))
            {
                InsertarRegistro(noCita, nss, medico, consultorio, fechaCita, hora,motivo,estado);
                string datos = $"No.Cita:{noCita}\r\nNSS:{nss}\r\nMedico: {medico}\r\nNo.Consultorio:{consultorio}\r\nFecha de Cita:{fechaCita}\r\nHora:{hora}\r\nMotivo:{estado}\r\nEstado de la Cita:{estado}\r\n";
                MessageBox.Show("Datos guardados con éxito en la base de datos.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MessageBox.Show("Datos guardados con exito:\n\n" + datos, "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void ValidarNoCita(object sender, EventArgs e)
        {
            if (!EsEnteroValido(tbNoCita.Text))
            {
                MessageBox.Show("Por favor, ingrese un número de cita válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbNoCita.Clear();
            }
        }

        private void ValidarNSS(object sender, EventArgs e)
        {
            TextBox textbox = (TextBox)sender;
            if (textbox.Text.Length == 9 && EsEnteroValidoDe9Digitos(textbox.Text))
            {
                textbox.BackColor = Color.LightGreen;
            }
            else
            {
                textbox.BackColor = Color.LightSalmon;
                MessageBox.Show("Por favor, ingrese un NSS valido", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textbox.Clear();
            }
        }

        private void ValidarMotivo(object sender, EventArgs e)
        {
            if (!EsTextoValido(tbMotivo.Text))
            {
                MessageBox.Show("Por favor, ingrese un motivo válido sin caracteres especiales.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbMotivo.Clear();
            }
        }

        private void ValidarMedico(object sender, EventArgs e)
        {
            if (cbMedico.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, seleccione un médico.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ValidarConsultorio(object sender, EventArgs e)
        {
            if (cbConsultorio.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, seleccione un número de consultorio.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ValidarHora(object sender, EventArgs e)
        {
            if (cbHora.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, seleccione una hora para la cita.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ValidarEstado(object sender, EventArgs e)
        {
            // Solo un CheckBox debe estar seleccionado
            if (chbPendiente.Checked && (chbConfirmada.Checked || chbCancelada.Checked) ||
                chbConfirmada.Checked && (chbPendiente.Checked || chbCancelada.Checked) ||
                chbCancelada.Checked && (chbPendiente.Checked || chbConfirmada.Checked))
            {
                MessageBox.Show("Por favor, seleccione solo un estado de la cita.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ((CheckBox)sender).Checked = false;
            }
        }

        private string ObtenerEstadoCita()
        {
            if (chbPendiente.Checked) return "Pendiente";
            if (chbConfirmada.Checked) return "Confirmada";
            if (chbCancelada.Checked) return "Cancelada";
            return string.Empty;
        }

        private bool EsTextoValido(string valor)
        {
            return Regex.IsMatch(valor, @"^[a-zA-Z\s\.,!?;:'""()\-]+$");
        }

        private bool EsEnteroValido(string valor)
        {
            return int.TryParse(valor, out _);
        }

        private bool EsEnteroValidoDe9Digitos(string valor)
        {
            long resultado;
            return long.TryParse(valor, out resultado) && valor.Length == 9;
        }


        private void Atras_Click(object sender, EventArgs e)
        {
            MenuPrin formularioMenu = new MenuPrin();
            formularioMenu.Show();
            this.Hide();
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            tbNoCita.Clear();
            tbNSS.Clear();
            tbMotivo.Clear();
            cbMedico.SelectedIndex = -1;
            cbConsultorio.SelectedIndex = -1;
            cbHora.SelectedIndex = -1;
            chbPendiente.Checked = chbConfirmada.Checked = chbCancelada.Checked = false;
        }
    }
}

