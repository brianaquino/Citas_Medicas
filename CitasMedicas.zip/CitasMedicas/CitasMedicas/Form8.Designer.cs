﻿namespace CitasMedicas
{
    partial class QR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.Detener = new System.Windows.Forms.Button();
            this.Camaras = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Atras = new System.Windows.Forms.Button();
            this.Escanear = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Camaras)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightBlue;
            this.panel1.Controls.Add(this.Detener);
            this.panel1.Controls.Add(this.Camaras);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.Atras);
            this.panel1.Controls.Add(this.Escanear);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.panel1.Size = new System.Drawing.Size(1151, 721);
            this.panel1.TabIndex = 13;
            // 
            // Detener
            // 
            this.Detener.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Detener.Location = new System.Drawing.Point(595, 584);
            this.Detener.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Detener.Name = "Detener";
            this.Detener.Size = new System.Drawing.Size(204, 39);
            this.Detener.TabIndex = 28;
            this.Detener.Text = "Detener QR";
            this.Detener.UseVisualStyleBackColor = true;
            this.Detener.Click += new System.EventHandler(this.Detener_Click);
            // 
            // Camaras
            // 
            this.Camaras.BackColor = System.Drawing.Color.Transparent;
            this.Camaras.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Camaras.Location = new System.Drawing.Point(176, 38);
            this.Camaras.Name = "Camaras";
            this.Camaras.Size = new System.Drawing.Size(801, 517);
            this.Camaras.TabIndex = 27;
            this.Camaras.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(220, 224);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 29);
            this.label7.TabIndex = 26;
            // 
            // Atras
            // 
            this.Atras.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Atras.Location = new System.Drawing.Point(16, 664);
            this.Atras.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Atras.Name = "Atras";
            this.Atras.Size = new System.Drawing.Size(204, 39);
            this.Atras.TabIndex = 10;
            this.Atras.Text = "Atras";
            this.Atras.UseVisualStyleBackColor = true;
            this.Atras.Click += new System.EventHandler(this.Atras_Click);
            // 
            // Escanear
            // 
            this.Escanear.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Escanear.Location = new System.Drawing.Point(322, 584);
            this.Escanear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Escanear.Name = "Escanear";
            this.Escanear.Size = new System.Drawing.Size(204, 39);
            this.Escanear.TabIndex = 13;
            this.Escanear.Text = "Escanear QR";
            this.Escanear.UseVisualStyleBackColor = true;
            this.Escanear.Click += new System.EventHandler(this.Escanear_Click);
            // 
            // QR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1175, 745);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "QR";
            this.Text = "Form8";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Camaras)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox Camaras;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button Atras;
        private System.Windows.Forms.Button Escanear;
        private System.Windows.Forms.Button Detener;
    }
}