﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CitasMedicas
{
    public partial class Registro : Form
    {
        //Datos de conexion a MySQL
        string conexionSQL = "Server=localhost;Port=3306;Database=sisterma_citas;Uid=root;Pwd=Sayuris71700305;";
        public Registro()
        {
            InitializeComponent();
            tbNombre.TextChanged += ValidarNombre;
            tbPaterno.TextChanged += ValidarPaterno;
            tbMaterno.TextChanged += ValidarMaterno;
            dtpNacimiento.MaxDate = DateTime.Today;
            tbTelefono.Leave += ValidarTelefono;
            tbNSS.Leave += ValidarNSS;
        }

        private void InsertarRegistro(string nss,string nombre, string paterno,string materno,string fechaNacimiento, string telefono)
        {
            using (MySqlConnection connection = new MySqlConnection(conexionSQL))
            {
                connection.Open();

                string insertQuery = "INSERT INTO paciente (Id_Paciente,Nombre,Paterno,Materno,Fecha_Nacimiento,Telefono)"
                    + "VALUES (@Id_Paciente,@Nombre,@Paterno,@Materno,@Fecha_Nacimiento,@Telefono)";

                using (MySqlCommand command = new MySqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@Id_Paciente", nss);
                    command.Parameters.AddWithValue("@Nombre", nombre);
                    command.Parameters.AddWithValue("@Paterno", paterno);
                    command.Parameters.AddWithValue("@Materno", materno);
                    command.Parameters.AddWithValue("@Fecha_Nacimiento", fechaNacimiento);
                    command.Parameters.AddWithValue("@Telefono", telefono);

                    command.ExecuteNonQuery();

                }
                connection.Close();
            }
        }

        private void Guardar_Click(object sender, EventArgs e)
        {
            string nss = tbNSS.Text;
            string nombre = tbNombre.Text;
            string paterno = tbPaterno.Text;
            string materno = tbMaterno.Text;
            string fechaNacimiento = dtpNacimiento.Value.ToString("yyyy/MM/dd");
            string telefono = tbTelefono.Text;

            //Validar que los campos selecionados tengan el formato correcto
            if ( EsEnteroValidoDe9Digitos(nss) && EsTextoValido(nombre) && EsTextoValido(paterno) && EsTextoValido(materno) && EsEnteroValidoDe10Digitos(telefono))
            {
                InsertarRegistro(nss,nombre,paterno,materno,fechaNacimiento,telefono);
                string datos = $"NSS:{nss}\r\nNombre(s):{nombre}\r\nPaterno: {paterno}\r\nMaterno:{materno}\r\nFecha de Nacimiento:{fechaNacimiento}\r\nTelefono:{telefono}\r\n";
                MessageBox.Show("Datos guardados con éxito en la base de datos.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MessageBox.Show("Datos guardados con exito:\n\n" + datos, "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    
        private void ValidarNombre(object sender, EventArgs e)
        {
            TextBox textbox = (TextBox)sender;
            if (!EsTextoValido(textbox.Text))
            {
                MessageBox.Show("Por favor, ingrese un nombre válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textbox.Clear();
            }
        }

        private void ValidarPaterno(object sender, EventArgs e)
        {
            TextBox textbox = (TextBox)sender;
            if (!EsTextoValido(textbox.Text))
            {
                MessageBox.Show("Por favor, ingrese un apellido válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textbox.Clear();
            }
        }

        private void ValidarMaterno(object sender, EventArgs e)
        {
            TextBox textbox = (TextBox)sender;
            if (!EsTextoValido(textbox.Text))
            {
                MessageBox.Show("Por favor, ingrese un apellido válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textbox.Clear();
            }
        }

        private void ValidarTelefono(object sender, EventArgs e)
        {
            TextBox textbox = (TextBox)sender;
            if (textbox.Text.Length == 10 && EsEnteroValidoDe10Digitos(textbox.Text))
            {
                textbox.BackColor = Color.LightGreen;
            }
            else
            {
                textbox.BackColor = Color.LightSalmon; 
                MessageBox.Show("Por favor, ingrese un numero de telefono valido", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textbox.Clear();
            }
        }

        private void ValidarNSS(object sender, EventArgs e)
        {
            TextBox textbox = (TextBox)sender;
            if (textbox.Text.Length == 9 && EsEnteroValidoDe9Digitos(textbox.Text))
            {
                textbox.BackColor = Color.LightGreen;
            }
            else
            {
                textbox.BackColor = Color.LightSalmon; 
                MessageBox.Show("Por favor, ingrese un NSS valido", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textbox.Clear();
            }
        }

        private bool EsTextoValido(string valor)
        {
            return Regex.IsMatch(valor, @"^[a-zA-Z\s]+$");
        }

        private bool EsEnteroValidoDe10Digitos(string valor)
        {
            long resultado;
            return long.TryParse(valor, out resultado) && valor.Length == 10;
        }

        private bool EsEnteroValidoDe9Digitos(string valor)
        {
            long resultado;
            return long.TryParse(valor, out resultado) && valor.Length == 9;
        }
   
        private void Atras_Click_1(object sender, EventArgs e)
        {
            MenuPrin formularioMenu = new MenuPrin();
            formularioMenu.Show();
            this.Hide();
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            tbNombre.Clear();
            tbPaterno.Clear();
            tbMaterno.Clear();
            tbTelefono.Clear();
            tbNSS.Clear();
            tbTelefono.BackColor = Color.White;
            tbNSS.BackColor = Color.White;
        }
    } 
}
