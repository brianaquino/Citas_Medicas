﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CitasMedicas
{
    public partial class Pacientes : Form
    {
        string conexionSQL = "Server=localhost;Port=3306;Database=sisterma_citas;Uid=root;Pwd=Sayuris71700305;";

        public Pacientes()
        {
            InitializeComponent();
        }

        private void Atras_Click(object sender, EventArgs e)
        {
            MenuPrin formularioMenu = new MenuPrin();
            formularioMenu.Show();
            this.Hide();
        }

        private void Pacientes_Load(object sender, EventArgs e)
        {
            using (MySqlConnection connection = new MySqlConnection(conexionSQL))
            {
                try
                {
                    connection.Open();
                    MessageBox.Show("Conexión exitosa");

                    // Modificar consulta si es necesario
                    string consulta = "SELECT * FROM paciente";
                    MySqlDataAdapter adaptador = new MySqlDataAdapter(consulta, connection);
                    DataTable dt = new DataTable();
                    adaptador.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        dgvPaciente.AutoGenerateColumns = true; // Asegurarse de que las columnas se generen automáticamente
                        dgvPaciente.DataSource = dt;
                        MessageBox.Show("Datos cargados correctamente.");
                    }
                    else
                    {
                        MessageBox.Show("No hay datos en la tabla.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al conectar o cargar datos: " + ex.Message);
                }
            }
        }
    }
}
