﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MessagingToolkit.QRCode.Codec;
using MessagingToolkit.QRCode.Codec.Data;
using AForge.Video;
using AForge.Video.DirectShow;

namespace CitasMedicas
{
    public partial class QR : Form
    {
        private VideoCaptureDevice videoSource;
        private Bitmap CapImage;
        private Timer t;
        private BackgroundWorker worker;

        public QR()
        {
            InitializeComponent();
            // Configuración del temporizador y BackgroundWorker
            t = new Timer();
            worker = new BackgroundWorker();
            worker.DoWork += Worker_Dowork;
            t.Tick += T_Tick;
            t.Interval = 1;
        }

        private void T_Tick(object sender, EventArgs e)
        {
            // Revisar si hay una imagen disponible
            if (CapImage != null && !worker.IsBusy)
                worker.RunWorkerAsync();
        }

        private void Worker_Dowork(object sender, DoWorkEventArgs e)
        {
            if (CapImage == null) return;

            try
            {
                QRCodeDecoder Decoder = new QRCodeDecoder();
                string decodedText = Decoder.decode(new QRCodeBitmapImage(CapImage));

                if (decodedText == "Camila" || decodedText == "Ernesto")
                {
                    this.Invoke((MethodInvoker)delegate {
                        t.Stop();
                        videoSource.SignalToStop();
                        worker.Dispose();
                        //Pto formulario nos diste en el %&*"#$%, amen//
                        MenuPrin formularioMenuPrin = new MenuPrin();
                        formularioMenuPrin.Show();
                        this.Hide();
                    });
                }
                else
                {
                    this.Invoke((MethodInvoker)delegate {
                        MessageBox.Show("QR incorrecto");
                    });
                }
            }
            catch (Exception)
            {
                // Manejar excepción en la decodificación
            }
        }

        private void videoSource_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            // Captura el frame de video en CapImage y lo muestra en el PictureBox
            CapImage = (Bitmap)eventArgs.Frame.Clone();
            Camaras.Image = CapImage;
        }

        private void Escanear_Click(object sender, EventArgs e)
        {
            try
            {
                // Enumerar dispositivos de video y seleccionar el primero
                var videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
                if (videoDevices.Count == 0)
                    throw new Exception("No se encontraron cámaras");

                videoSource = new VideoCaptureDevice(videoDevices[0].MonikerString);
                videoSource.NewFrame += new NewFrameEventHandler(videoSource_NewFrame);

                videoSource.Start();
                t.Start();

                Detener.Enabled = true;
                Escanear.Enabled = false;
            }
            catch (Exception ex)
            {
                if (videoSource != null && videoSource.IsRunning)
                    videoSource.SignalToStop();

                MessageBox.Show(ex.Message);
            }

        }

        private void Detener_Click(object sender, EventArgs e)
        {
            if (videoSource != null && videoSource.IsRunning)
            {
                videoSource.SignalToStop();
                t.Stop();
                CapImage = null;

                Detener.Enabled = false;
                Escanear.Enabled = true;
            }
        }
    
        private void Atras_Click(object sender, EventArgs e)
        {
            Inicio formularioIni = new Inicio();
            formularioIni.Show();
            this.Hide();
        }

    }
}
